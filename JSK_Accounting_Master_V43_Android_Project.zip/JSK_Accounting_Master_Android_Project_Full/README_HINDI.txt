JSK Accounting Master - Android project

यह प्रोजेक्ट आपके दिए हुए AJ Accounting Master V43 HTML को app/src/main/assets/index.html में रखता है।
MainActivity WebView में JavaScript और DOM Storage चालू करता है।

मोबाइल से GitHub Actions के जरिए APK बनाने के लिए:
1. इस ZIP को Extract करें।
2. GitHub repository में पूरा project folder structure अपलोड करें। फ़ाइलें root पर सपाट (flatten) करके न डालें।
3. सुनिश्चित करें कि .github/workflows/android-build.yml repository में उसी path पर हो।
4. GitHub > Actions > Build JSK Accounting Master APK > Run workflow चुनें।
5. Build सफल होने पर run के Artifacts सेक्शन से JSK-Accounting-Master-debug-apk डाउनलोड करें।

ध्यान दें: यह Android project source है, APK नहीं। GitHub Actions पर build चलाकर ही APK artifact बनेगा।
